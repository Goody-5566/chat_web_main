## 增加一个Kubernetes的部署方式
```
kubectl apply -f deploy.yaml
```

### 如果需要Ingress域名接入
```
kubectl apply -f ingress.yaml
```
